# LaTeX source - Specialized project report

This source follows the structure of dacn (1).zip and the visual style of DACN___HK241.pdf.

## Compilation

Open main.tex in Overleaf or another XeLaTeX environment. Because preamble.tex uses fontspec, compile with XeLaTeX or LuaLaTeX rather than pdfLaTeX.

The source is divided into:

main.tex
preamble.tex
frontmatter/ (cover, commitment, abstract)
chapters/ (chapters 1 to 8, following the DACN_HK241 report structure)
appendices/ (schedule and task assignment)
references.bib
hcmut.png

## Task assignment

- Khoi: problem formulation, the 2025 baseline paper, semantic/OCR/ASR/object retrieval, temporal/TRAKE retrieval, and AI evaluation.
- Thai: stakeholders, frontend/backend/API, database, authentication/RBAC, UI/UX, testing, and system evaluation.
- Both: integration, final testing, screenshots, measured results, conclusions, and cross-review.

The markers [KHOI - ...], [THAI - ...], [BOTH - ...], and [TODO: ...] are placeholders that must be completed before submission. Do not insert benchmark values that have not been measured on the current pipeline.

enhancemutimodel.pdf is used as the 2025 foundation. The SOICT 2026 draft was not accepted or published and is treated only as an internal extension, not as an established publication.

The product-first scope decisions are recorded in REPORT_SCOPE_DECISIONS.md at the repository root. Application code has not been changed by the report-scaffolding work.
